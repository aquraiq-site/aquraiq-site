export default function Home() {
  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-r from-blue-500 to-indigo-600">
      <h1 className="text-white text-4xl font-bold">Welcome to AquraIQ 🚀</h1>
    </div>
  )
}